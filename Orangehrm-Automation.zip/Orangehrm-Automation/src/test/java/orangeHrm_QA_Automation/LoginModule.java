package orangeHrm_QA_Automation;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.jspecify.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

//Login module class
public class LoginModule {

	public String Baseurl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";

	public WebDriver driver;
//setup method for OrangeHRM website

	@BeforeTest
	public void setup() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(Baseurl);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));

	}

//positive TestCase
//login method with valid credentials
	@Test(priority = 1)
	public void logintest() {

//UserName	
		WebElement Usernamefield = driver.findElement(By.xpath("//input[@name='username']"));
		Usernamefield.sendKeys("Admin");
//Password
		WebElement passwordfield = driver.findElement(By.xpath("//input[@name='password']"));
		passwordfield.sendKeys("admin123");
//LoginButton
		WebElement loginbuttonfield = driver.findElement(By.xpath("//button[@type='submit']"));
		loginbuttonfield.click();

//Verify if the login was successful by checking the page title or a specific element
		@Nullable
		String pagetitle = driver.getTitle();
		/*
		 * if (pagetitle.equals("OrangeHRM")) { System.out.println("Login Succesfull");
		 * } else { System.out.println("Login Failed");
		 * 
		 * }
		 */
		Assert.assertEquals("OrangeHRM", pagetitle);
		System.out.println("Login Successfully Done......");

	}

	// Negative TestCase
	// login method with invalid credentials
	@Test(priority = 2, enabled = false)
	public void Invalidcredential() {

		// UserName
		WebElement Usernamefield = driver.findElement(By.xpath("//input[@name='username']"));
		Usernamefield.sendKeys("123456");
		// Password
		WebElement passwordfield = driver.findElement(By.xpath("//input[@name='password']"));
		passwordfield.sendKeys("asdfghjkl");
		// LoginButton
		WebElement loginbuttonfield = driver.findElement(By.xpath("//button[@type='submit']"));
		loginbuttonfield.click();

		String ExpectedMessage = "Invalid credentials";
		String ActualMessage = driver
				.findElement(By.xpath("//p[@class=\"oxd-text oxd-text--p oxd-alert-content-text\"]")).getText();

		Assert.assertEquals(ActualMessage, ExpectedMessage);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		System.out.println("Invalid credentials message displayed successfully");
	}

	@Test(priority = 3, enabled = false)

	public void AddEmployee() {
		// click the PIM
		WebElement PIMmodule = driver.findElement(By.linkText("PIM"));
		PIMmodule.click();

		// Click the Add Employee

		WebElement AddEmployee = driver.findElement(By.xpath("//a[text()='Add Employee']"));
		AddEmployee.click();

		// Find FirstName
		WebElement Firstname = driver.findElement(By.xpath("//input[@placeholder=\"First Name\"]"));
		Firstname.sendKeys("Monisha");
		// Find the lastName

		WebElement Lastname = driver.findElement(By.xpath("//input[@placeholder=\"Last Name\"]"));

		Lastname.sendKeys("Ravi");
//save button
		WebElement button = driver.findElement(By.xpath("//button[normalize-space()='Save']"));

		button.click();

		// Verify the employee is successfully added or not
		String Confirmatrionmessage = driver.findElement(By.xpath("//h6[normalize-space()='Personal Details']"))
				.getText();

		if (Confirmatrionmessage.contains("Personal Details")) {
			System.out.println("Employee Details added successfully........");
		} else {
			System.out.println("Employee Details Failed to add......");
		}
	}

	// Navigate to the claim module
	@Test(priority = 4, enabled = false)
	public void claim() {

		WebElement claimmodule = driver.findElement(By.xpath("//a[@class=\"oxd-main-menu-item active\"]"));
		claimmodule.click();
		// Assign Claim
		WebElement Assignclaim = driver
				.findElement(By.xpath("//button[@class=\"oxd-button oxd-button--medium oxd-button--secondary\"]"));
		Assignclaim.click();
		// Employee name
		WebElement Employeename = driver.findElement(By.xpath("//input[@placeholder=\"Type for hints...\"]"));
		Employeename.sendKeys("Monisha  Ravi");
		// Event Find
		WebElement Eventfind = driver
				.findElement(By.xpath("//div[@class=\"oxd-select-text oxd-select-text--active\"][1]"));
		Eventfind.click();
		WebElement Event = driver.findElement(By.linkText("Accommodation"));
		Event.click();
//createbutton
		WebElement createbutton = driver.findElement(By.xpath("//button[@type=\"submit\"]"));

		createbutton.click();
		// verify Assign claim created successfully or not
		String Confirmatrionmessage = driver.findElement(By.xpath("//h6[normalize-space()='Personal Details']"))
				.getText();

		if (Confirmatrionmessage.contains("Personal Details")) {
			System.out.println("Claim request added successfully........");
		} else {
			System.out.println("Claim request cancelled......");
		}

	}

//Search by employeeid
	@Test(priority = 3, enabled = false)
	public void searchid() {

		String empid = "123456";
		// click the PIM
		WebElement PIMmodule = driver.findElement(By.linkText("PIM"));
		PIMmodule.click();
//Employee List
		WebElement Employeelist = driver.findElement(By.xpath("//a[normalize-space()='Employee List"));
		Employeelist.click();

		driver.findElements(By.tagName("input")).get(2).sendKeys(empid);
		// click the searchbutton
		WebElement searchbutton = driver.findElement(By.xpath("//button[normalize-space()='Search']"));

		searchbutton.click();
		List<WebElement> rows = driver.findElements(By.xpath("//div[@role='row']"));
		if (rows.size() > 1) {
			WebElement actualmessage = driver.findElement(By.xpath("((//div[@role='row'])[2]/div[@role='cell'])[2]"));
			String actual = actualmessage.getText();
			Assert.assertEquals(empid, actual);
		}

	}

	// image upload

	@SuppressWarnings("deprecation")
	@Test(priority = 5)

	public void imageupload() throws IOException {
		// click the PIM
		WebElement PIMmodule = driver.findElement(By.linkText("PIM"));
		PIMmodule.click();

		// Click the Add Employee

		WebElement AddEmployee = driver.findElement(By.xpath("//a[text()='Add Employee']"));
		AddEmployee.click();

		// Find FirstName
		WebElement Firstname = driver.findElement(By.xpath("//input[@placeholder=\"First Name\"]"));
		Firstname.sendKeys("Monisha");
		// Find the lastName

		WebElement Lastname = driver.findElement(By.xpath("//input[@placeholder=\"Last Name\"]"));

		Lastname.sendKeys("Ravi");
//save button

		WebElement uploadimage = driver.findElement(By.id("//i[@class=\"oxd-icon bi-plus\"]"));
		uploadimage.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		Runtime.getRuntime().exec(
				"C:\\Users\\hp\\eclipse-workspace\\Orangehrm-Automation\\src\\test\\java\\orangeHrm_QA_Automation\\orangehrmimage");
		driver.findElement(By.xpath("//button[@type='submit]")).submit();

	}

	// LogoutField
	@Test(priority = 4, enabled = false)
	public void logout() {
		WebElement logoutfield = driver.findElement(By.xpath("//img[@class='oxd-userdropdown-img']"));

		logoutfield.click();

		List<WebElement> dropdownlist = driver.findElements(By.xpath("//ul[@class='oxd-dropdown-menu']"));
		for (int i = 0; i < dropdownlist.size(); i++) {
			System.out.println(i + ":" + dropdownlist.get(i).getText());

		}
		dropdownlist.get(3).click();
		System.out.println("Logout Successfully Done......");
	}

	@AfterTest

	public void closingtest() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		driver.close();
		driver.quit();

	}

}
