package orangeHrm_QA_Automation;

import java.time.Duration;

import org.jspecify.annotations.Nullable;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginwithPageobjects {

	public String Baseurl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";

	public WebDriver driver;
//setup method for OrangeHRM website	

	@BeforeTest
	public void setup() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(Baseurl);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));

	}

//positive TestCase
//login method with valid credentials
	@Test(priority = 1)
	public void logintest() {
		PageObjects pg = new PageObjects(driver);
		pg.setusername("Admin");
		pg.setpassword("admin123");
		pg.clickloginbutton();

//Verify if the login was successful by checking the page title or a specific element
		@Nullable
		String pagetitle = driver.getTitle();
		/*
		 * if (pagetitle.equals("OrangeHRM")) { System.out.println("Login Succesfull");
		 * } else { System.out.println("Login Failed");
		 * 
		 * }
		 */
		Assert.assertEquals("OrangeHRM", pagetitle);
		System.out.println("Login Successfully Done......");

	}
}
