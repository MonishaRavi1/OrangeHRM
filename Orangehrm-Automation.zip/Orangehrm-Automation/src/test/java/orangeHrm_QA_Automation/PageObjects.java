package orangeHrm_QA_Automation;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageObjects {
WebDriver d;
//webElements of login page
	@FindBy(name = "username")
	WebElement username;

	@FindBy(name = "password")
	WebElement password;
	@FindBy(xpath = "//button[@type='submit']")
	WebElement loginbutton;



	public PageObjects(WebDriver driver) {
	d=driver;
	PageFactory.initElements(d, driver);
	}

	public void setusername(String name) {
		username.sendKeys(name);

	}

	public void setpassword(String pass) {
		password.sendKeys(pass);

	}

	public void clickloginbutton() {

		loginbutton.submit();
	}



}

