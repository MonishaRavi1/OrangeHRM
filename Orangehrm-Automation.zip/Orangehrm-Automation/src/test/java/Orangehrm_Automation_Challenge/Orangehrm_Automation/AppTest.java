package Orangehrm_Automation_Challenge.Orangehrm_Automation;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AppTest {
    
  @Test
  public void shouldAnswerWithTrue() {
    assertTrue(true);
  }
}
