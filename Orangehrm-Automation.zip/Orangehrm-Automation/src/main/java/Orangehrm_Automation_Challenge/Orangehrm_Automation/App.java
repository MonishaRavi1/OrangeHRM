package Orangehrm_Automation_Challenge.Orangehrm_Automation;

public class App {
  public static void main(String[] args) {
    System.out.println("Hello World!");
  }
}
